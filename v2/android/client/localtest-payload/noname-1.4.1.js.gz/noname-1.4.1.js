// ==UserScript==
// @name         clean-compatible-configurable
// @namespace    R
// @version      1.4.1
// @description  H5 202611040001 适配（自写悬浮窗 + 免登录 + 免费购买）
// @author
// @run-at       document-start
// @match        https://m.66rpg.com/h5/*
// @match        https://m.66rpg.com/mini/*
// @match        https://www.66rpg.com/*
// @grant        none
// ==/UserScript==

/* ============================================================================
 * 1.2.0：整段重写，不再包含 1.1.3 的混淆核心。
 *
 * 为什么丢掉核心：
 *   1.1.3 核心会把官方 game.js 改写成它自己的托管引擎（workers.dev/engine/stable.js），
 *   页面用 tempName.indexOf("game.js") 判"引擎是否启用"，被改写就 location.replace('about:blank')
 *   —— 白屏、悬浮窗一起消失（桌面已复现）。
 *   它还对 XHR / RegExp / Function 等原型做改写，会命中页面引擎内置的 disable-devtool 检测，
 *   触发后同样跳 about:blank。
 *
 * 这一版只做三件事，且全部是"读页面状态 + 轻量写"，不改任何内置原型：
 *   ① 悬浮窗（自带，id=gg-panel）
 *   ② 免登录：合成用户 + 锁 commonPlayer 登录态 + 摘 SAL_Login / login.midLogin
 *   ③ 免费购买：拦截 createBuyOrder 的 XHR 响应，回"已成交"订单（可开关）
 * ========================================================================== */
;(() => {
  "use strict";
  if (window.__GG_V120__) return;
  window.__GG_V120__ = true;

  const CFG = {
    bypassLogin: true,
    freeMall: false,
    uid: 10000001,
    flower: 999999,
    uname: "游客"
  };
  try {
    const saved = JSON.parse(localStorage.getItem("gg_v120_cfg") || "null");
    if (saved && typeof saved === "object") Object.assign(CFG, saved);
  } catch (e) { }

  const saveCfg = () => {
    try { localStorage.setItem("gg_v120_cfg", JSON.stringify({ bypassLogin: CFG.bypassLogin, freeMall: CFG.freeMall })); } catch (e) { }
  };

  /* ---------------- 合成用户 ---------------- */
  const pin = (obj, key, val) => {
    try {
      Object.defineProperty(obj, key, { configurable: true, enumerable: true, get: () => val, set: () => { } });
    } catch (e) { }
  };
  const GUEST = {
    uid: CFG.uid, uname: CFG.uname, username: CFG.uname, nick_name: CFG.uname,
    token: "guest-token", status: "ok",
    real_name: "已实名", real_age: 20, is_visitor: 0, force_login: 0,
    vip_level: 0, author_level: 0, angel_logo: 0, avatar: "",
    account_info: "", account_type: "", email: "", login_type: "", mobile: "",
    nick_name_set: 0, regdate: "", screen_game_ad: 0, screen_scroll_ad: 0,
    session_loginday: "", super_title: "", temp_vip_end_time: "", temp_vip_level: "",
    user_exp: 0, user_level: 0,
    fresh_flower_num: 999999, num: 999999, sum: 999999, tanhua_flower_num: 999999, wild_flower_num: 999999
  };
  pin(GUEST, "uid", CFG.uid);
  pin(GUEST, "is_visitor", 0);

  /* ---------------- 免登录 ---------------- */
  let myInit = null, myMid = null, mySal = null;
  const seed = () => {
    const $ = window.jQuery;
    if (!$) return false;
    try {
      const d = $("#data").data("user");
      if (!d || d.uid === undefined || d.uid === false) $("#data").data("user", GUEST);
      return true;
    } catch (e) { return false; }
  };
  const lockPlayer = () => {
    const cp = window.commonPlayer;
    if (!cp) return false;
    try {
      Object.defineProperty(cp, "userInfos", { configurable: true, enumerable: true, get: () => GUEST, set: () => { } });
      Object.defineProperty(cp, "loginStatus", { configurable: true, enumerable: true, get: () => true, set: () => { } });
    } catch (e) { }
    try {
      if (cp.login) {
        myInit = myInit || function (cb) { seed(); try { cb && cb(); } catch (e) { } };
        myMid = myMid || function (cb) { try { cb && cb(); } catch (e) { } };
        if (cp.login.init !== myInit) cp.login.init = myInit;
        if (cp.login.midLogin !== myMid) cp.login.midLogin = myMid;
      }
      if (cp.flower && !cp.flower.__ggPin) {
        cp.flower.__ggPin = true;
        ["fresh_flower_num", "num", "sum", "tanhua_flower_num", "wild_flower_num"].forEach((k) => pin(cp.flower, k, 999999));
      }
      if (cp.sendFlower && !cp.sendFlower.__ggPin) {
        cp.sendFlower.__ggPin = true;
        cp.sendFlower.userCoin = { coin2: { coin_count: 999999 }, coin_count: 999999, flower: 999999 };
        cp.sendFlower.sendFlowerState = function (cb, type) { try { cb && cb(999999, type); } catch (e) { } };
      }
    } catch (e) { }
    return true;
  };
  const lockSso = () => {
    const sso = window.ssoLogin;
    if (!sso || sso.__ggFixed) return;
    try {
      sso.ajaxAsync = function () {
        seed(); lockPlayer();
        try { if (typeof window.ajaxLoginCall === "function") window.ajaxLoginCall(); } catch (e) { }
      };
      sso.__ggFixed = true;
    } catch (e) { }
  };
  const lockSal = () => {
    if (typeof window.SAL_Login !== "function") return;
    mySal = mySal || function (cb) { try { cb && cb(); } catch (e) { } };
    if (window.SAL_Login !== mySal) { try { window.SAL_Login = mySal; } catch (e) { } }
  };

  /* ---------------- 免费购买（只改 XHR 的 responseText，不动原型方法） ---------------- */
  let mallHooked = false;
  const hookMall = () => {
    if (mallHooked || !CFG.freeMall) return;
    const X = window.XMLHttpRequest;
    if (!X || !X.prototype) return;
    mallHooked = true;
    const rawOpen = X.prototype.open;
    const rawSend = X.prototype.send;
    if (!rawOpen || !rawSend) return;
    X.prototype.open = function (m, u) {
      try { this.__ggUrl = String(u == null ? "" : u); } catch (e) { }
      return rawOpen.apply(this, arguments);
    };
    X.prototype.send = function () {
      const xhr = this;
      try {
        if (CFG.freeMall && /createBuyOrder/i.test(xhr.__ggUrl || "")) {
          const orig = xhr.onreadystatechange;
          xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
              let n = 1;
              try {
                const pd = arguments && arguments[0];
                const txt = (xhr.__ggBody || "") + "";
                const m = /"goods_num"\s*:\s*(\d+)/.exec(txt) || /"buy_num"\s*:\s*(\d+)/.exec(txt);
                if (m) n = parseInt(m[1], 10) || 1;
              } catch (e) { }
              const body = JSON.stringify({ status: 1, msg: "ok", data: { buy_num: n, order_id: "GG" + Date.now(), pay_status: 1, is_free: 1, price: 0, money: 0 } });
              try {
                Object.defineProperty(xhr, "responseText", { configurable: true, get: () => body });
                Object.defineProperty(xhr, "response", { configurable: true, get: () => body });
                Object.defineProperty(xhr, "status", { configurable: true, get: () => 200 });
              } catch (e) { }
            }
            if (typeof orig === "function") return orig.apply(this, arguments);
          };
        }
        if (typeof arguments[0] === "string") xhr.__ggBody = arguments[0];
      } catch (e) { }
      return rawSend.apply(this, arguments);
    };
  };

  /* ---------------- 悬浮窗 ---------------- */

  /* ---------------- 修改器（变量读取/修改） ---------------- */
  const NOTE_KEY = "gg_var_notes_v1";
  const loadNotes = () => { try { return JSON.parse(localStorage.getItem(NOTE_KEY) || "{}"); } catch (e) { return {}; } };
  const saveNotes = (o) => { try { localStorage.setItem(NOTE_KEY, JSON.stringify(o)); } catch (e) { } };
  const gameKey = () => {
    try {
      var m = location.pathname.match(/(\d{5,})/);
      return m ? m[1] : location.pathname;
    } catch (e) { return "game"; }
  };

  const varStores = () => {
    const list = window.__GGV || [];
    const out = [];
    for (let i = 0; i < list.length; i++) {
      const st = list[i];
      if (!st || typeof st.setVar !== "function" || !st.data) continue;
      out.push(st);
    }
    return out;
  };

  const classify = (v) => {
    if (Array.isArray(v)) return "数组";
    if (v === null || v === undefined) return "空";
    if (typeof v === "number") return "数值";
    if (typeof v === "object") return "对象";
    const sv = String(v);
    if (sv !== "" && !isNaN(sv)) return "数值";
    return "文本";
  };

  const buildVarsWindow = () => {
    if (document.getElementById("gg-vars")) return document.getElementById("gg-vars");
    const w = document.createElement("div");
    w.id = "gg-vars";
    w.style.cssText = "position:fixed;left:12px;top:12px;right:12px;bottom:60px;z-index:2147483647;display:none;" +
      "background:rgba(18,18,22,.96);color:#eee;border:1px solid #444;border-radius:10px;font:13px/1.5 -apple-system,Segoe UI,sans-serif;flex-direction:column;overflow:hidden";
    w.innerHTML =
      '<div style="display:flex;gap:8px;align-items:center;padding:8px 10px;border-bottom:1px solid #333">' +
      '<b style="color:#9cf">修改器</b>' +
      '<button id="gg-tab-var" style="padding:4px 10px">变量</button>' +
      '<button id="gg-tab-save" style="padding:4px 10px">存档</button>' +
      '<button id="gg-tab-srch" style="padding:4px 10px">搜索</button>' +
      '<input id="gg-vs" placeholder="搜索 id / 值 / 备注" style="flex:1;background:#222;border:1px solid #444;color:#eee;border-radius:6px;padding:4px 8px">' +
      '<button id="gg-vr" style="padding:4px 10px">刷新</button>' +
      '<button id="gg-vc" style="padding:4px 10px">关闭</button>' +
      '</div>' +
      '<div id="gg-vlist" style="flex:1;overflow:auto;padding:6px 10px"></div>' +
      '<div id="gg-vtip" style="padding:6px 10px;border-top:1px solid #333;color:#8a8">说明：改完立即写入引擎；备注会记住（按作品）。</div>';
    document.body.appendChild(w);
    w.querySelector("#gg-vc").onclick = () => { w.style.display = "none"; };
    w.__mode = "var";
    w.querySelector("#gg-tab-var").onclick = () => { w.__mode = "var"; renderVars(true); };
    w.querySelector("#gg-tab-save").onclick = () => { w.__mode = "save"; renderActive(); };
    w.querySelector("#gg-tab-srch").onclick = () => { w.__mode = "search"; renderActive(); };
    w.querySelector("#gg-vr").onclick = () => renderActive();
    w.querySelector("#gg-vs").oninput = () => { clearTimeout(w.__deb); w.__deb = setTimeout(() => renderActive(), 260); };
    return w;
  };

  let vTimer = null;
  const openVars = () => {
    const w = buildVarsWindow();
    w.style.display = "flex";
    renderActive();
    if (vTimer) clearInterval(vTimer);
    vTimer = setInterval(() => {
      if (w.style.display === "none") return;
      const ae = document.activeElement;
      // 正在输入框里打字时绝不重建，避免光标闪烁/丢焦点
      if (ae && w.contains(ae) && /^(INPUT|TEXTAREA)$/.test(ae.tagName)) return;
      renderActive();
    }, 3000);
  };


  /* ---------------- 存档编辑器（通用：读 localStorage 里的 save*） ---------------- */
  const findSaveKey = () => {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.indexOf("save") === 0) return k;
    }
    return null;
  };
  const readSave = () => {
    const k = findSaveKey();
    if (!k) return null;
    try { return { key: k, obj: JSON.parse(localStorage.getItem(k)) }; } catch (e) { return null; }
  };
  const flatten = (obj, prefix, out, depth) => {
    if (depth > 2 || obj === null || typeof obj !== "object") return;
    const keys = Object.keys(obj);
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      const v = obj[k];
      const path = prefix ? prefix + "." + k : k;
      if (v !== null && typeof v === "object" && !Array.isArray(v)) {
        flatten(v, path, out, depth + 1);
      } else if (Array.isArray(v)) {
        out.push({ path: path, type: "数组", shown: "[" + v.length + " 项]", editable: false });
      } else {
        out.push({ path: path, type: typeof v === "number" ? "数值" : (typeof v === "string" ? "文本" : typeof v), shown: String(v), editable: true, raw: v });
      }
    }
  };


  /* ---------------- 存档快照（备份 / 还原 / 重载生效） ---------------- */
  const SNAP_KEY = "gg_save_snaps_v1";
  const loadSnaps = () => { try { return JSON.parse(localStorage.getItem(SNAP_KEY) || "{}"); } catch (e) { return {}; } };
  const saveSnaps = (o) => { try { localStorage.setItem(SNAP_KEY, JSON.stringify(o)); } catch (e) { } };
  const snapSave = () => {
    const sv = readSave();
    if (!sv) return false;
    const all = loadSnaps();
    const gk = gameKey();
    all[gk] = all[gk] || [];
    all[gk].unshift({ ts: Date.now(), key: sv.key, data: localStorage.getItem(sv.key) });
    all[gk] = all[gk].slice(0, 3);
    saveSnaps(all);
    return true;
  };
  const snapRestore = (idx) => {
    const all = loadSnaps();
    const arr = all[gameKey()] || [];
    const snap = arr[idx];
    if (!snap) return false;
    try { localStorage.setItem(snap.key, snap.data); return true; } catch (e) { return false; }
  };
  const snapList = () => loadSnaps()[gameKey()] || [];

  const renderSave = (box, kw) => {
    const sv = readSave();
    if (!sv) { box.innerHTML = '<div style="color:#f88">没找到存档（还没进游戏）。</div>'; return; }
    const snaps = snapList();
    const bar =
      '<div style="display:flex;gap:6px;align-items:center;padding:0 0 8px;border-bottom:1px solid #333;margin-bottom:6px">' +
      '<button id="gg-snap-new" style="padding:3px 10px">备份存档</button>' +
      '<button id="gg-snap-load" style="padding:3px 10px"' + (snaps.length ? "" : " disabled") + '>还原最近备份</button>' +
      '<button id="gg-reload2" style="padding:3px 10px">重载存档（生效）</button>' +
      '<span style="color:#888">备份 ' + snaps.length + '/3' +
      (snaps.length ? " · 最近 " + new Date(snaps[0].ts).toLocaleTimeString() : "") + "</span>" +
      "</div>";
    const rows = [];
    flatten(sv.obj, "", rows, 0);
    const kwl = (kw || "").toLowerCase();
    const html = rows.filter((r) => !kwl || (r.path + " " + r.shown).toLowerCase().indexOf(kwl) >= 0)
      .slice(0, 600)
      .map((r) => {
        const val = String(r.shown).replace(/"/g, "&quot;");
        return '<div style="display:flex;gap:6px;align-items:center;padding:3px 0;border-bottom:1px dashed #2a2a2a">' +
          '<span style="width:46px;color:#7ac">' + r.type + '</span>' +
          '<span style="flex:1;color:#9bd;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + r.path + '">' + r.path + '</span>' +
          (r.editable
            ? '<input data-spath="' + r.path + '" value="' + val + '" style="width:110px;background:#222;border:1px solid #444;color:#eee;border-radius:4px;padding:2px 4px">' +
              '<button data-sapply="' + r.path + '" style="padding:2px 8px">改</button>'
            : '<span style="color:#666">只读</span>') +
          '</div>';
      }).join("");
    box.innerHTML = bar + (html || '<div style="color:#aaa">没有匹配项。</div>');

    const bn = box.querySelector("#gg-snap-new");
    if (bn) bn.onclick = () => { snapSave() ? toastVar("已备份（最多 3 份）") : toastVar("备份失败：没有存档"); renderSave(box, kw); };
    const bl = box.querySelector("#gg-snap-load");
    if (bl) bl.onclick = () => {
      if (!confirm("用最近一次备份覆盖当前存档？")) return;
      snapRestore(0) ? (toastVar("已还原备份"), renderSave(box, kw)) : toastVar("还原失败");
    };
    const br = box.querySelector("#gg-reload2");
    if (br) br.onclick = () => location.reload();
    box.querySelectorAll("[data-sapply]").forEach((btn) => {
      btn.onclick = () => {
        const path = btn.getAttribute("data-sapply");
        const inp = box.querySelector('[data-spath="' + path + '"]');
        if (!inp) return;
        const fresh = readSave();
        if (!fresh) return;
        const parts = path.split(".");
        let cur = fresh.obj;
        for (let i = 0; i < parts.length - 1; i++) {
          cur = cur[parts[i]];
          if (!cur) { toastVar("路径不存在"); return; }
        }
        const last = parts[parts.length - 1];
        const oldVal = cur[last];
        let nv = inp.value;
        if (typeof oldVal === "number") nv = Number(nv);
        else if (typeof oldVal === "boolean") nv = (nv === "true");
        cur[last] = nv;
        try {
          localStorage.setItem(fresh.key, JSON.stringify(fresh.obj));
          toastVar("已写入存档：" + path + "（刷新后完全生效）");
        } catch (e) { toastVar("写入失败：" + e.message); }
      };
    });
  };


  /* ---------------- 数值搜索（按游戏里看到的值反查） ---------------- */
  const SRCH = { value: null, hits: null };

  const writeSavePath = (path, nv) => {
    const fresh = readSave();
    if (!fresh) return false;
    const parts = path.split(".");
    let cur = fresh.obj;
    for (let i = 0; i < parts.length - 1; i++) {
      cur = cur[parts[i]];
      if (!cur || typeof cur !== "object") return false;
    }
    cur[parts[parts.length - 1]] = nv;
    try { localStorage.setItem(fresh.key, JSON.stringify(fresh.obj)); return true; } catch (e) { return false; }
  };

  const walkDeep = (obj, prefix, depth, out, seen) => {
    if (!obj || typeof obj !== "object" || depth > 4 || out.length > 1500) return;
    if (seen.has(obj)) return;
    seen.add(obj);
    let keys = [];
    try { keys = Object.keys(obj); } catch (e) { return; }
    for (let i = 0; i < keys.length && out.length < 1500; i++) {
      const k = keys[i];
      let v;
      try { v = obj[k]; } catch (e) { continue; }
      const path = prefix ? prefix + "." + k : k;
      if (typeof v === "number") out.push({ path: path, v: v, holder: obj, key: k });
      else if (v && typeof v === "object" && !Array.isArray(v)) walkDeep(v, path, depth + 1, out, seen);
    }
  };

  const collectSources = () => {
    const out = [];
    // A. 变量容器
    (window.__GGV || []).forEach((st) => {
      if (!st || !st.data || typeof st.setVar !== "function") return;
      const d = st.data;
      Object.keys(d).forEach((k) => {
        if (typeof d[k] !== "number") return;
        out.push({ src: "变量", path: "#" + k, raw: d[k], apply: (nv) => st.setVar(k, nv) });
      });
    });
    // B. 存档标量
    const sv = readSave();
    if (sv) {
      const rows = [];
      flatten(sv.obj, "", rows, 0);
      rows.forEach((r) => {
        if (r.type !== "数值") return;
        const p = r.path;
        out.push({ src: "存档", path: p, raw: Number(r.shown), apply: (nv) => writeSavePath(p, nv) });
      });
    }
    // C. 引擎数据对象（浅层）
    const deep = [];
    walkDeep(window.__GGDATA, "data", 0, deep, new Set());
    deep.forEach((x) => out.push({ src: "引擎", path: x.path, raw: x.v, apply: (nv) => { try { x.holder[x.key] = nv; } catch (e) { } } }));
    return out;
  };

  const renderSearch = (box) => {
    const cur = SRCH.value === null ? "" : String(SRCH.value);
    const hits = SRCH.hits;
    let html =
      '<div style="display:flex;gap:6px;align-items:center;padding:4px 0 8px">' +
      '<span style="color:#7ac">游戏里的数值</span>' +
      '<input id="gg-sv" value="' + cur + '" placeholder="例如 15" style="width:90px;background:#222;border:1px solid #444;color:#eee;border-radius:4px;padding:3px 6px">' +
      '<button id="gg-s-first" style="padding:3px 10px">搜索</button>' +
      '<button id="gg-s-next" style="padding:3px 10px">值变了，再搜</button>' +
      '<button id="gg-s-reset" style="padding:3px 10px">重置</button>' +
      '<span style="color:#888">' + (hits ? ("候选 " + hits.length + " 个") : "未搜索") + "</span>" +
      "</div>";
    if (hits && hits.length) {
      html += hits.slice(0, 200).map((h, i) => {
        return '<div style="display:flex;gap:6px;align-items:center;padding:3px 0;border-bottom:1px dashed #2a2a2a">' +
          '<span style="width:44px;color:#7ac">' + h.src + "</span>" +
          '<span style="flex:1;color:#9bd;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + h.path + '">' + h.path + "</span>" +
          '<input data-sv2="' + i + '" value="' + String(h.raw) + '" style="width:90px;background:#222;border:1px solid #444;color:#eee;border-radius:4px;padding:2px 4px">' +
          '<button data-sap="' + i + '" style="padding:2px 8px">改</button>' +
          "</div>";
      }).join("");
    } else if (hits) {
      html += '<div style="color:#f88">没有候选。请确认数值没变，或先「重置」再搜一次。</div>';
    } else {
      html += '<div style="color:#aaa;line-height:1.7">用法：<br>1) 输入你在游戏里看到的数值 → 点「搜索」<br>2) 回游戏让这个值变化（比如加 1）→ 输入新值 → 点「值变了，再搜」<br>3) 候选收敛到几个时，直接改成你要的值</div>';
    }
    box.innerHTML = html;

    const readVal = () => Number((box.querySelector("#gg-sv") || {}).value);
    const first = box.querySelector("#gg-s-first");
    const next = box.querySelector("#gg-s-next");
    const reset = box.querySelector("#gg-s-reset");
    if (first) first.onclick = () => {
      const v = readVal();
      if (isNaN(v)) { toastVar("请输入数值"); return; }
      SRCH.value = v;
      const all = collectSources();
      SRCH.hits = all.filter((x) => Number(x.raw) === v);
      toastVar("搜索完成：" + SRCH.hits.length + " 个候选");
      renderSearch(box);
    };
    if (next) next.onclick = () => {
      const v = readVal();
      if (isNaN(v) || !SRCH.hits) { toastVar("先搜索一次"); return; }
      SRCH.value = v;
      SRCH.hits = SRCH.hits.filter((x) => Number(x.raw) === v);
      toastVar("剩余候选：" + SRCH.hits.length);
      renderSearch(box);
    };
    if (reset) reset.onclick = () => { SRCH.value = null; SRCH.hits = null; renderSearch(box); };

    box.querySelectorAll("[data-sap]").forEach((btn) => {
      btn.onclick = () => {
        const i = Number(btn.getAttribute("data-sap"));
        const h = SRCH.hits && SRCH.hits[i];
        if (!h) return;
        const inp = box.querySelector('[data-sv2="' + i + '"]');
        const nv = Number(inp.value);
        if (isNaN(nv)) { toastVar("请输入数值"); return; }
        try {
          h.apply(nv);
          toastVar("已改 " + h.path + " → " + nv + (h.src === "存档" ? "（刷新后生效）" : ""));
          h.raw = nv;
        } catch (e) { toastVar("修改失败：" + e.message); }
      };
    });
  };

  const renderActive = () => {
    const w = document.getElementById("gg-vars");
    if (!w) return;
    const box = w.querySelector("#gg-vlist");
    const kw = (w.querySelector("#gg-vs").value || "").trim();
    if (w.__mode === "save") { renderSave(box, kw); return; }
    if (w.__mode === "search") { renderSearch(box); return; }
    renderVars(true);
  };

  const renderVars = (rebuild) => {
    const w = document.getElementById("gg-vars");
    if (w && w.__mode === "save") { renderSave(w.querySelector("#gg-vlist"), (w.querySelector("#gg-vs").value || "").trim()); return; }
    if (w && w.__mode === "search") { return; }
    if (!w) return;
    const box = w.querySelector("#gg-vlist");
    const kw = (w.querySelector("#gg-vs").value || "").trim().toLowerCase();
    const notes = loadNotes();
    const gk = gameKey();
    notes[gk] = notes[gk] || {};
    const stores = varStores();
    if (!stores.length) {
      box.innerHTML = '<div style="color:#f88">还没抓到变量容器：请先在游戏里推进剧情/打开菜单，容器出现后会自动显示。</div>';
      return;
    }
    const rows = [];
    for (let si = 0; si < stores.length; si++) {
      const st = stores[si];
      const data = st.data || {};
      const keys = Object.keys(data);
      for (let k = 0; k < keys.length; k++) {
        const id = keys[k];
        const val = data[id];
        const type = classify(val);
        if (type === "空" || type === "对象") continue;
        const note = notes[gk][id] || "";
        const shown = Array.isArray(val) ? "[" + val.length + " 项]" : String(val);
        const hay = (id + " " + shown + " " + note).toLowerCase();
        if (kw && hay.indexOf(kw) < 0) continue;
        rows.push({ si: si, id: id, type: type, shown: shown, note: note, raw: val });
      }
    }
    if (!rows.length) {
      box.innerHTML = '<div style="color:#aaa">没有匹配项。</div>';
      return;
    }
    const html = rows.slice(0, 500).map((r, idx) => {
      const key = r.si + "_" + r.id;
      const valInput = r.type === "数组" ? "" : String(r.raw).replace(/"/g, "&quot;");
      return '<div style="display:flex;gap:6px;align-items:center;padding:3px 0;border-bottom:1px dashed #2a2a2a">' +
        '<span style="width:56px;color:#888">#' + r.id + '</span>' +
        '<span style="width:44px;color:#7ac">' + r.type + '</span>' +
        '<input data-note="' + key + '" value="' + r.note.replace(/"/g, "&quot;") + '" placeholder="备注/名字" style="width:110px;background:#1c1c22;border:1px solid #333;color:#fd8;border-radius:4px;padding:2px 4px">' +
        '<span style="flex:1;color:#bdf;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + String(r.shown).replace(/"/g, "&quot;") + '">' + r.shown + '</span>' +
        (r.type === "数组" ? "" :
          '<input data-edit="' + key + '" value="' + valInput + '" style="width:90px;background:#222;border:1px solid #444;color:#eee;border-radius:4px;padding:2px 4px">' +
          '<button data-apply="' + key + '" style="padding:2px 8px">改</button>') +
        '</div>';
    }).join("");
    box.innerHTML = html;

    box.querySelectorAll("[data-apply]").forEach((btn) => {
      btn.onclick = () => {
        const key = btn.getAttribute("data-apply");
        const si = Number(key.split("_")[0]);
        const id = key.substring(key.indexOf("_") + 1);
        const inp = box.querySelector('[data-edit="' + key + '"]');
        if (!inp) return;
        let v = inp.value;
        const st = stores[si];
        const old = (st.data || {})[id];
        if (typeof old === "number" || (!isNaN(Number(v)) && String(v).trim() !== "" && classify(old) === "数值")) v = Number(v);
        try {
          st.setVar(id, v);
          toastVar("已修改 #" + id + " = " + v);
          renderVars(true);
          try {
            const again = document.querySelector('[data-edit="' + key + '"]');
            if (again) { again.focus(); again.select(); }
          } catch (e) { }
        } catch (e) { toastVar("修改失败：" + e.message); }
      };
    });
    box.querySelectorAll("[data-note]").forEach((inp) => {
      inp.onchange = () => {
        const key = inp.getAttribute("data-note");
        const id = key.substring(key.indexOf("_") + 1);
        notes[gk][id] = inp.value;
        saveNotes(notes);
      };
    });
  };

  const toastVar = (msg) => {
    const t = document.createElement("div");
    t.textContent = msg;
    t.style.cssText = "position:fixed;left:50%;top:12%;transform:translateX(-50%);background:rgba(0,0,0,.85);color:#7f7;" +
      "padding:8px 14px;border-radius:8px;z-index:2147483647;font:13px/1.4 sans-serif";
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 1600);
  };

  const buildPanel = () => {
    if (document.getElementById("gg-panel")) return;
    const css = document.createElement("style");
    css.id = "gg-panel-style";
    css.textContent = `
      #gg-fab{position:fixed;right:10px;bottom:90px;width:44px;height:44px;border-radius:50%;
        background:#1f6feb;color:#fff;font:600 16px/44px -apple-system,"Segoe UI",sans-serif;text-align:center;
        box-shadow:0 4px 12px rgba(0,0,0,.35);z-index:2147483000;user-select:none;cursor:pointer}
      #gg-panel{position:fixed;right:10px;bottom:146px;width:228px;background:#12181f;color:#dfe7f0;
        border:1px solid #2a3span;border-radius:12px;padding:10px 12px;z-index:2147483001;
        font:13px/1.6 -apple-system,"Segoe UI",sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.45);display:none}
      #gg-panel h4{margin:0 0 6px;font-size:13px;color:#9fb3c8;font-weight:600}
      #gg-panel .row{display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-top:1px solid #1e2833}
      #gg-panel .row:first-of-type{border-top:none}
      #gg-panel button{background:#1b2530;border:1px solid #2c3a4a;color:#cfe0f2;border-radius:8px;
        padding:3px 10px;font-size:12px;cursor:pointer}
      #gg-panel button.on{background:#1f6feb;border-color:#1f6feb;color:#fff}
      #gg-panel .tip{margin-top:6px;color:#6e8296;font-size:11px}
    `;
    document.head ? document.head.appendChild(css) : document.documentElement.appendChild(css);

    const fab = document.createElement("div");
    fab.id = "gg-fab";
    fab.textContent = "G";
    fab.title = "设置";

    const panel = document.createElement("div");
    panel.id = "gg-panel";
    panel.innerHTML = `
      <h4>设置（1.4.1）</h4>
      <div class="row"><span>免登录</span><button id="gg-toggle-login"></button></div>
      <div class="row"><span>免费购买</span><button id="gg-toggle-mall"></button></div>
      <div class="row" id="gg-flower-row"><span>鲜花</span><button id="gg-flower">999999</button></div>
      <div class="row"><span>商城</span><button id="gg-unlock">全解锁</button></div>
      <div class="row"><span>变量</span><button id="gg-vars-btn">修改器</button></div>
      <div class="row"><span>操作</span><button id="gg-reload">重新载入</button></div>
      <div class="tip" id="gg-state">状态：-</div>
    `;

    const mount = () => {
      document.body.appendChild(fab);
      document.body.appendChild(panel);
      const paint = () => {
        const a = panel.querySelector("#gg-toggle-login");
        const b = panel.querySelector("#gg-toggle-mall");
        a.textContent = CFG.bypassLogin ? "开" : "关"; a.className = CFG.bypassLogin ? "on" : "";
        b.textContent = CFG.freeMall ? "开" : "关"; b.className = CFG.freeMall ? "on" : "";
        const cp = window.commonPlayer || {};
        panel.querySelector("#gg-state").textContent =
          "状态：" + (cp.loginStatus ? "已登录" : "未登录") +
          " / uid=" + ((window.jQuery && window.jQuery("#data").data("user") || {}).uid);
      };
      fab.onclick = () => { panel.style.display = panel.style.display === "block" ? "none" : "block"; paint(); };
      panel.querySelector("#gg-toggle-login").onclick = () => {
        CFG.bypassLogin = !CFG.bypassLogin; saveCfg(); paint();
        if (CFG.bypassLogin) { seed(); lockPlayer(); lockSal(); }
      };
      panel.querySelector("#gg-unlock").onclick = () => {
        const ok = unlockAllGoods();
        panel.querySelector("#gg-state").textContent = ok ? "状态：商品已全部解锁" : "状态：未取到商城数据";
      };
      panel.querySelector("#gg-flower").onclick = () => {
        CFG.flower = (Number(CFG.flower) >= 999999) ? 99999999 : 999999999;
        applyFlower();
        panel.querySelector("#gg-flower").textContent = CFG.flower;
      };
      panel.querySelector("#gg-toggle-mall").onclick = () => {
        CFG.freeMall = !CFG.freeMall; saveCfg(); paint();
        if (CFG.freeMall) hookMall();
      };
      panel.querySelector("#gg-vars-btn").onclick = () => { panel.style.display = "none"; openVars(); };
      panel.querySelector("#gg-reload").onclick = () => location.reload();
      paint();
      setInterval(paint, 1000);
    };
    if (document.body) mount();
    else document.addEventListener("DOMContentLoaded", mount, { once: true });
  };

  /* ---------------- 主循环 ---------------- */
  const applyFlower = () => {
    const N = Number(CFG.flower) || 999999;
    if (window.__ggApplied === N) return;
    window.__ggApplied = N;
    const n = Number(CFG.flower) || 999999;
    try { if (window.gameInfo) { window.gameInfo.flowerMallHua = n; window.gameInfo.userFlower = n; } } catch (e) { }
    try { if (window.infoTool && window.infoTool.getHaveFlower) window.infoTool.getHaveFlower = function () { return n; }; } catch (e) { }
  };

  const poisonUserData = () => {
    try {
      const raw = window.SAL_getUserData;
      if (typeof raw !== "function" || raw.__ggPoison) return;
      const f = function () {
        let d = {};
        try { d = raw() || {}; } catch (e) { }
        const out = {};
        try { for (const k in d) if (Object.prototype.hasOwnProperty.call(d, k)) out[k] = d[k]; } catch (e) { }
        out.uid = CFG.uid;
        out.token = "guest-token";
        out.isLogin = true;
        out.vip_level = 0;
        out.haveFlower = Number(CFG.flower) || 999999;
        return out;
      };
      f.__ggPoison = true;
      window.SAL_getUserData = f;
    } catch (e) { }
  };

  // 打赏/购买最后都落到 commonPlayer.sendFlower，这里整体本地化，避免走服务端"验身"导致卡住或未登录
  const stubFlower = () => {
    const cp = window.commonPlayer;
    if (!cp || cp.__ggFlowerStub) return;
    cp.__ggFlowerStub = true;
    const N = Number(CFG.flower) || 999999;
    let sf = cp.sendFlower;
    if (!sf) { sf = {}; try { Object.defineProperty(cp, "sendFlower", { configurable: true, enumerable: true, get: () => sf, set: () => { } }); } catch (e) { cp.sendFlower = sf; } }
    sf.userCoin = { coin2: { coin_count: N }, coin_count: N, flower: N };
    sf.sendFlowerState = function (cb) { try { cb && cb(N); } catch (e) { } };
    sf.up_Sent_Flower = function (num, cb) {
      try {
        var n = parseInt(num, 10) || 1;
        if (!sf.userCoin) sf.userCoin = { coin1: { coin_count: 0 }, coin2: { coin_count: N } };
        if (!sf.userCoin.coin2) sf.userCoin.coin2 = { coin_count: N };
        if (!sf.userCoin.coin1) sf.userCoin.coin1 = { coin_count: 0 };
        sf.userCoin.coin2.coin_count = (Number(sf.userCoin.coin2.coin_count) || 0) - n;
        sf.userCoin.coin1.coin_count = (Number(sf.userCoin.coin1.coin_count) || 0) + 30 * n;
        cb && cb("送花成功了");
      } catch (e) { }
    };
    ["getFlower", "getFlowerCount", "refreshUserFlower", "getHaveFlower", "upUserFlower"].forEach(function (k) {
      try { sf[k] = function (cb) { if (typeof cb === "function") cb(N); return N; }; } catch (e) { }
    });
  };

  // 商城「购」会走 SAL_payMoney -> 支付/打赏面板 -> 服务端。这里直接接管：
  // 不打开面板，按"支付成功"回调，引擎随即走它自己的成交分支（配合引擎侧 P5/P13）。
  // 直接把商城商品标记为"已购买"：写引擎自己的 gameInfo.newMallBuyData
  const unlockAllGoods = () => {
    const gi = window.gameInfo;
    if (!gi) return false;
    const collect = (mall) => {
      const list = mall && mall.goodList && mall.goodList.goods;
      if (!Array.isArray(list)) return [];
      const out = [];
      for (let i = 0; i < list.length; i++) {
        const g = list[i] || {};
        const id = g.itemId || g.id || g.goods_id;
        if (id !== undefined && id !== null) out.push({ id: id, count: 1 });
      }
      return out;
    };
    const goods = collect(gi.gameNewMall).concat(collect(gi.gameTimeMall), collect(gi.gameMallItemData));
    if (!goods.length) return false;
    if (!Array.isArray(gi.newMallBuyData)) gi.newMallBuyData = [];
    for (let i = 0; i < goods.length; i++) {
      const g = goods[i];
      let has = false;
      for (let j = 0; j < gi.newMallBuyData.length; j++) {
        const b = gi.newMallBuyData[j] || {};
        if ((b.id !== undefined ? b.id : b.itemId) === g.id) { has = true; break; }
      }
      if (!has) gi.newMallBuyData.push({ id: g.id, count: g.count, buy_num: g.count });
    }
    try { if (typeof gi.refreshNewMall === "function") gi.refreshNewMall(); } catch (e) { }
    return true;
  };
  window.__ggUnlockAll = unlockAllGoods;

  const tick = () => {
    stubFlower();
    poisonUserData();
    if (CFG.bypassLogin) applyFlower();
    if (CFG.bypassLogin) {
      lockSso();
      lockSal();
      if (seed()) lockPlayer();
    }
    if (CFG.freeMall) hookMall();
  };
  setInterval(tick, 1200);
  tick();
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => { tick(); buildPanel(); }, { once: true });
  else { buildPanel(); }
})();
